# nbx-pseudo-spark

This repository contains a copy of the NBX pseudonymization library for distribution within spire.

This is not maintained by the spire team.
For more information see [NB(x) Pseudonymization Service](https://social.cloud.corpintra.net/docs/DOC-186895).
